# Quartz atomic geometry and energy starting-point audit

Read `2026-09-14_QUARTZ_ATOMIC_GEOMETRY_AND_ENERGY_FIRST_CONSTRUCTION.md` for the scientific record, limitations, and source trail.

This package contains a NumPy-only reproducible calculation of the periodic nine-atom quartz geometry, rigid-tetrahedron compatibility, and a separate reciprocal linear piezoelectric energy control. It is not an atomistically resolved field-flow solver or an ARK validation.

Run:

```bash
python -m pip install numpy
python quartz_cell_audit.py --out results
```

The included `results/` files are the actual run outputs. Numerical precision is not physical measurement precision. The code performs no network access and does not alter any repository or external data.
